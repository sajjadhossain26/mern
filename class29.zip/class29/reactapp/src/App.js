import Input from "./Componnent/Input/Input";

function App() {
  return (
    <>
      <Input />
    </>
  );
}

export default App;
